<template>
    <v-container fluid>
        <v-row>
            <v-col cols="12" md="6">
                <select-link @update-links="updateSelectedLinks" :links="links" />
            </v-col>
            <v-col cols="12" md="6">
                <submit-form :selected-links="selectedLinks" />
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
import SelectLink from './SelectLink.vue';
import SubmitForm from './Submit.vue';

export default {
    components: {
        SelectLink,
        SubmitForm
    },
    data() {
        return {
            links: [
                { value: "Google", text: "https://www.google.com", checked: false },
                { value: "Facebook", text: "https://www.facebook.com", checked: false },
                { value: "Twitter", text: "https://www.twitter.com", checked: false },
                { value: "LinkedIn", text: "https://www.linkedin.com", checked: false },
                { value: "GitHub", text: "https://www.github.com", checked: false }
            ],
            selectedLinks: []
        };
    },
    methods: {
        updateSelectedLinks(selectedLinks) {
            this.selectedLinks = selectedLinks;
        }
    }
};
</script>
