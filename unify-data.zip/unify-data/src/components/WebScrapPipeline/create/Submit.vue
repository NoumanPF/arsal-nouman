<template>

    <v-container>

        <v-form>

            <v-text-field  label="Title" v-model="Title"
                class="mb-3"></v-text-field>

            <!-- Dropdown for Selecting a Destination -->

            <v-select v-model="selectedDestination" :items="destinations" label="Select a Destination" outlined
                class="mb-3"></v-select>

            
            <!-- Sync Time Input -->

            <v-text-field v-model.number="syncValue" label="Sync Time Value" outlined type="number"
                class="mb-3"></v-text-field>

            <!-- Dropdown for Sync Time Units -->

            <v-select v-model="syncUnit" :items="units" label="Select Time Unit" outlined class="mb-3"></v-select>

            <!-- Submit Button -->

            <v-btn color="primary" @click="submitData" class="mb-3">Submit</v-btn>

        </v-form>

    </v-container>

</template>

<script>

import axios from 'axios';

export default {

    props: {



        selectedLinks: {

            type: Array,

            required: true

        }

    },

    data() {

        return {

            Title: '', // This will hold the title entered by the user
            selectedDestination: null,

            syncValue: 0, // Ensure the default value is a number

            syncUnit: null,

            units: ['Days', 'Hours', 'Minutes'],

            destinations: [] // This will hold names of destinations dynamically

        };

    },

    mounted() {

        this.fetchDestinations(); // Fetch destinations when the component is mounted
        console.log(this.selectedLinks);
    },

    methods: {

        fetchDestinations() {

            const apiUrl = 'http://10.0.52.168:8081/api/connectors';

            axios.get(apiUrl, {

                headers: {

                    'Authorization': 'Bearer 66b59c40a6aa52a5490dd8a5|LyAjoLs0U3YpaDS1ErOnBH55x9dx9ktcqCrdrRcVe47b8fc1'

                }

            }).then(response => {

                this.destinations = response.data.destinations.map(item => item.name); // Assuming response.data is an array of objects

                console.log("Fetched destinations:", this.destinations);

            })

                .catch(error => {

                    console.error("Error fetching destinations:", error);

                    alert('Failed to fetch destinations');

                });

        },

        submitData() {
            const apiUrl = 'http://10.0.52.168:8081/api/website-info';
            const postData = {
                title: this.Title,
                selectedLinks: this.selectedLinks,

                selectedDestination: this.selectedDestination,

                syncTime: this.convertedSyncTime

            };
            axios.post(apiUrl, postData, {
                headers: {
                    'Authorization': 'Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b'
                }
            }).then(response => {

                console.log('Update successful:', response.data);

                alert('Title updated successfully');

                this.fetchConnections(); // Refresh connections if needed

            })

                .catch(error => {

                    console.error('Error updating title:', error);

                    alert('Failed to update title');

                    console.log(this.Title);

                    console.log(this.selectedLinks);

                });

        
    },

},

computed: {

    convertedSyncTime() {

        const value = parseFloat(this.syncValue);

        if (isNaN(value) || value <= 0 || !this.syncUnit) {

            return 0;

        }

        let seconds = 0;

        switch (this.syncUnit) {

            case 'Days':

                seconds = value * 86400; // 1 day = 86400 seconds

                break;

            case 'Hours':

                seconds = value * 3600; // 1 hour = 3600 seconds

                break;

            case 'Minutes':

                seconds = value * 60; // 1 minute = 60 seconds

                break;

        }

        return seconds;

    }

}

};

</script>

<style scoped>
/* Additional styles can be added here if needed */
</style>
