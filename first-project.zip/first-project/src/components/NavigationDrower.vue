<template>
    <v-navigation-drawer app v-model="drawer" :rail="rail" permanent @click="handleDrawerClick">

        <v-list density="compact" nav>
            <v-list-item>
                <v-icon>mdi-view-dashboard</v-icon>
                <span>Unify Data</span>
                <template v-slot:append>
                    <v-icon style="font-size: 24px;" icon @click.stop="toggleRail">{{ rail ?
                        'mdi-chevron-right' :
                        'mdi-chevron-left' }}</v-icon>
                </template>


            </v-list-item>
            <v-divider></v-divider>
            <v-list-item v-for="item in dashboardItems" :key="item.value" :prepend-icon="item.icon" :title="item.title"
                :value="item.value" class="custom-list-item" @click="handleItemClick(item.value)"></v-list-item>
        </v-list>

        <v-list-item prepend-avatar="https://randomuser.me/api/portraits/men/85.jpg" title="John Leider"
            class="custom-list-item">
        </v-list-item>
    </v-navigation-drawer>
</template>

<script>
export default {
    data() {
        return {
            drawer: true,
            rail: true,
            dashboardItems: [
                { value: 'Dashboard', icon: 'mdi-view-dashboard', title: 'Dashboard' },
                { value: 'pipe-line', icon: 'mdi-pipe', title: 'Pipelines' },
                { value: 'Source', icon: 'mdi-power-plug', title: 'Source' },
                { value: 'transformation', icon: 'mdi-swap-horizontal-variant', title: 'Transformation' },
                { value: 'destination', icon: 'mdi-map-marker-circle', title: 'Destination' },
                { value: 'build-ai-connection', icon: 'mdi-connection', title: 'Build AI Connections' },
                { value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
                { value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' }
            ],

        };
    },
    methods: {
        handleDrawerClick() {
            this.rail = false; // Close rail on any click inside the drawer
        },
        toggleRail() {
            this.rail = !this.rail;
        },
        handleItemClick(value) {
            console.log(`Item clicked: ${value}`);
            // Handle navigation or item-specific actions here
        }
    }
};
</script>

<style>
.custom-list-item {
    background-color: #f0f0f0;
    color: #333;
    transition: background-color 0.3s ease;
}

.custom-list-item:hover {
    background-color: #e0e0e0;
    color: #023C83;
    font-size: 20px;
}

.custom-btn {
    color: black;
    border-radius: 0%;
    font-size: 10px;
}

/* .custom-app-bar {
    color: rgb(0, 0, 0);
} */

.custom-toolbar-title {
    font-weight: bold;
    font-size: 1.5rem;
}

.custom-header {
    font-weight: bold;
    font-size: 1.2rem;
    padding: 10px;
    color: #555;
}

.a {
    height: 100vh;
}

.v-list-item {
    background-color: white;
}


</style>