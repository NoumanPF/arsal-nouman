<template>
  <v-app theme="light">
    <div id="a">
      <div id="c">
        <HelloWorld></HelloWorld>
      </div>
      <div id="b">
        <AppFooter></AppFooter>
      </div>
    </div>
  </v-app>
</template>

<script>
export default {

}
</script>

<style>
#a {
  display: flex;
  flex-direction: row;
}

#b{
  width: 100%;
}
</style>
