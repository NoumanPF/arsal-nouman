<template>
  <div class="text-center">
    <v-menu
      v-model="popup"
      :close-on-content-click="false"
      location="end"
    >
      <template v-slot:activator="{ props }">
        
        <v-list-item  
        v-bind="props" prepend-avatar="https://img.freepik.com/free-vector/user-with-pie-chart_78370-7032.jpg?uid=R158325715&ga=GA1.1.1210946705.1723102697&semt=ais_hybrid" title="Muhammad Nouman" ></v-list-item>

      </template>

      <v-card min-width="300">
        <v-list>
 
          <v-list-item
                v-for="item in appendItems"
                :key="item.value"
                :prepend-icon="item.icon"
                :title="item.title"
                :value="item.value"
                :active="selectedItem === item.value"
                :class="{'custom-list-item': true, 'selected-item': selectedItem === item.value}"
                @click="handleItemClick(item)"
            ></v-list-item>
        </v-list>
      </v-card>
    </v-menu>
  </div>
</template>
<script>
  export default {
    data: () => ({
      fav: true,
      popup: false,
      message: false,
      hints: true,
      appendItems: [
                { route: '/Settings', value: 'Setting', icon: 'mdi-cog', title: 'Setting' },
                { route: '/Logout', value: 'Logout', icon: 'mdi-logout', title: 'Logout' },
            ]
    }),
    methods: {
        
        handleItemClick(item) {
            console.log(`Item clicked: ${item.value}`);
            this.selectedItem = item.value;
            this.$router.push(item.route);  // Navigate to the route
        }
    }
  }
</script>

