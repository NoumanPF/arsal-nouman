<template>
  <v-app theme="light" style="background-color: #E3E3E3;">
     <Home></Home>
  </v-app>
</template>

<script>
import Home from './components/Home.vue';
export default {

}
</script>

<style>


</style>
