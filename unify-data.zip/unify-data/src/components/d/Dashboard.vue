<template>
    <div><h1>this is route</h1></div>
    </template>
    
    <script>
    </script>
    
    
    <style>
    </style>