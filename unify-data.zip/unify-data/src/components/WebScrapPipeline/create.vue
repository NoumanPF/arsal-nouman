<template>
    <v-stepper v-model="step" :items="items" show-actions>
        <template v-slot:item.1>
            <h3 class="text-h6">Enter URL you want to scrap: </h3>
            <br>
            <url></url>
        </template>

        <template v-slot:item.2>
            <h3 class="text-h6">Select multiple links you want to scrap: </h3>

            <SelectLink></SelectLink>
        </template>

        <template v-slot:item.3>
            <Submit></Submit>
        </template>
    </v-stepper>
</template>
<script>
import SelectLink from './create/SelectLink.vue';

export default {
    data: () => ({
        shipping: 0,
        step: 1,
        items: [
            'Enter URL',
            'Select Links',
            'Submit',
        ],
        products: [
            {
                name: 'Product 1',
                price: 10,
                quantity: 2,
            },
            {
                name: 'Product 2',
                price: 15,
                quantity: 10,
            },
        ],
    }),

    computed: {
        subtotal() {
            return this.products.reduce((acc, product) => acc + product.quantity * product.price, 0)
        },
        total() {
            return this.subtotal + Number(this.shipping ?? 0)
        },
    },
}
</script>