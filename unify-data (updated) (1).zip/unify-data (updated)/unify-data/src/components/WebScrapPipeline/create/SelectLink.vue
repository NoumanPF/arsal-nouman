<template>
    <v-container fluid>
        <v-row>
            <ul style="list-style: none; padding: 0;">
                <li v-for="(link, index) in links" :key="index" class="d-flex align-items-center">
                    <input type="checkbox" v-model="link.checked" class="mr-2" @change="updateLinks">
                    <a :href="link.text" target="_blank" rel="noopener noreferrer" style="text-decoration: none; color: inherit;">
                        {{ link.text }}
                    </a>
                </li>
            </ul>
        </v-row>
    </v-container>
</template>

<script>
export default {
    props: {
        links: {
            type: Array,
            required: true
        }
    },
    methods: {
        updateLinks() {
            const selectedLinks = this.links.filter(link => link.checked);
            this.$emit('update-links', selectedLinks);
        }
    }
};
</script>
