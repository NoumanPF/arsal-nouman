<template>
  <v-app theme="light">
    <v-card>
      <v-layout>
        <v-navigation-drawer v-model="drawer" class="bg-white" theme="light" app :rail="rail" permanent
          @click="rail = false">
          <h1 class="ma-2 pl-5 mb-1">
            <v-icon>mdi-menu</v-icon>
            <span class="ml-3" style="color: #023C83;">Unify Data</span>
          </h1>
         
          <v-divider></v-divider>

          <v-list-item style="color: rgb(0, 0, 0 , 0.5);"><b>Dashboard</b></v-list-item>

          <v-list color="transparent" class="ml-5 custom-list">
            <v-list-item v-for="item in items" :key="item.value" @click="handleClick(item.value)"
              class="custom-list-item">
              <v-icon>{{ item.icon }}</v-icon>
              <span class="ml-2">{{ item.title }}</span>
            </v-list-item>
          </v-list>

          <v-list-item style="color: rgb(0, 0, 0 , 0.5);"><b>Editor</b></v-list-item>

          <v-list color="transparent" class="ml-5 custom-list">
            <v-list-item v-for="item in editorItems" :key="item.value" @click="handleClick(item.value)"
              class="custom-list-item">
              <v-icon>{{ item.icon }}</v-icon>
              <span class="ml-2">{{ item.title }}</span>
            </v-list-item>
          </v-list>

          <template v-slot:append>
            <div class="pa-2">
              <v-list class="custom-list">
                <v-list-item v-for="appendItem in appendItems" :key="appendItem.value"
                  @click="handleClick(appendItem.value)" class="custom-list-item">
                  <v-icon>{{ appendItem.icon }}</v-icon>
                  <span class="ml-2">{{ appendItem.title }}</span>
                </v-list-item>
                <v-divider></v-divider>
                <v-divider></v-divider>
                <v-list-item value="account">
                  <v-icon>mdi-account-circle-outline</v-icon>
                  <span class="ml-2  custom-title"> Muhammad Nouman</span>
                </v-list-item>

              </v-list>
            </div>
          </template>
        </v-navigation-drawer>
       <NavBar></NavBar>
        <v-main style="min-height: 100vh;"></v-main>
      </v-layout>
    </v-card>
   
  </v-app>
</template>

<script>
import NavBar from './NavBar.vue';



export default {

  name: 'HelloWorld',
  data() {
    return {

      rail: false,
      drawer: true,
      items: [
        { value: 'Dashboard', icon: 'mdi-view-dashboard', title: 'Dashboard' },
        { value: 'pipe-line', icon: 'mdi-pipe', title: 'Pipelines' }
        // ,{ value: 'pipe-line', icon: 'mdi-pipe', title: 'Pipelines' }
      ],
      editorItems: [
        { value: 'Source', icon: 'mdi-power-plug', title: 'Source' },
        { value: 'transformation', icon: 'mdi-swap-horizontal-variant', title: 'Transformation' },
        { value: 'destination', icon: 'mdi-map-marker-circle', title: 'Destination' },
        { value: 'build-ai-connection', icon: 'mdi-connection', title: 'Build AI Connections' }
      ],
      appendItems: [
        { value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
        { value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' },

      ]
    };
  },
  methods: {
    handleClick(value) {
      console.log(`Item clicked: ${value}`);
      // Handle the item click, such as navigation or other actions
    }
  }
};
</script>

<style scoped>
h1 {
  font-family: 'Roboto', sans-serif;
}

.custom-list-item {
  height: 0px;
  /* Adjust the height as needed */
  display: flex;
  align-items: center;
  /* Center content vertically */
  margin: 0px;
  padding: 0px;
}



.custom-list .v-list-item {
  font-size: 13px;
  color: #494552;

  /* Adjust the font size as needed */
}

.custom-list-item:hover {
  color: #023C83;
  font-size: 14px;
}

.custom-title {
  font-size: 14PX;

}
</style>
