<template>
  <v-app class="bg-white">
    <v-toolbar color="white" class="custom-toolbar">
      
      <v-spacer></v-spacer>
      <v-btn icon>
        <v-icon>mdi-bell</v-icon>
      </v-btn>
     
    </v-toolbar>
    

    <v-divider></v-divider>
  </v-app>
</template>

<script>
export default {
  name: 'AppFooter'
}
</script>

<style scoped>
.custom-toolbar{
  height: 57.5px;
}
</style>
