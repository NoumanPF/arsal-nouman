<template>
  <v-app theme="light">
    <v-card>
      <v-layout>
        <v-navigation-drawer
          v-model="drawer"
          class="bg-white"
          theme="light"
          app
          permanent
          
        >
          <h1 class="ma-2 pl-5 mb-3" permanent>
            <v-icon>mdi-menu</v-icon>
            <span class="ml-3" style="color: #023C83;">Unify Data</span>
          </h1>

          <v-divider></v-divider>

          <v-list-item title="Dashboard"></v-list-item>

          <v-list color="transparent" class="ml-5 custom-list">
            <v-list-item
              v-for="item in items"
              :key="item.value"
              @click="handleClick(item.value)"
            >
              <v-icon>{{ item.icon }}</v-icon>
              <span class="ml-2">{{ item.title }}</span>
            </v-list-item>
          </v-list>

          <v-list-item title="Editor"></v-list-item>

          <v-list color="transparent" class="ml-5 custom-list">
            <v-list-item
              v-for="item in editorItems"
              :key="item.value"
              @click="handleClick(item.value)"
            >
              <v-icon>{{ item.icon }}</v-icon>
              <span class="ml-2">{{ item.title }}</span>
            </v-list-item>
          </v-list>

          <template v-slot:append>
            <div class="pa-2">
              <v-list class="custom-list">
                <v-list-item
                  v-for="appendItem in appendItems"
                  :key="appendItem.value"
                  @click="handleClick(appendItem.value)"
                >
                  <v-icon>{{ appendItem.icon }}</v-icon>
                  <span class="ml-2">{{ appendItem.title }}</span>
                </v-list-item>
                <v-divider></v-divider>
              </v-list>
            </div>
          </template>
        </v-navigation-drawer>
        <v-main style="min-height: 100vh ; po"></v-main>
      </v-layout>
    </v-card>
  </v-app>
</template>

<script>
export default {
  name: 'HelloWorld',
  data() {
    return {
      drawer: true,
      items: [
        { value: 'Dashboard', icon: 'mdi-view-dashboard', title: 'Dashboard' },
        { value: 'pipe-line', icon: 'mdi-pipe', title: 'Pipe line' }
      ],
      editorItems: [
        { value: 'Source', icon: 'mdi-power-plug', title: 'Source' },
        { value: 'transformation', icon: 'mdi-swap-horizontal-variant', title: 'Transformation' },
        { value: 'destination', icon: 'mdi-map-marker-circle', title: 'Destination' },
        { value: 'build-ai-connection', icon: 'mdi-connection', title: 'Build AI Connections' }
      ],
      appendItems: [
        { value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
        { value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' },
        { value: 'account', icon: 'mdi-account-circle-outline', title: 'Muhammad Nouman' }
      ]
    };
  },
  methods: {
    handleClick(value) {
      console.log(`Item clicked: ${value}`);
      // Handle the item click, such as navigation or other actions
    }
  }
};
</script>

<style scoped>
h1 {
  font-family: 'Roboto', sans-serif;
}

.custom-list .v-list-item {
  font-size: 14px;
  /* Adjust the font size as needed */
}


</style>
