<template>
    <v-container>
        <!-- Data Table with search and action slots -->
        <v-data-table :items="filteredConnections" class="border">
            <template v-slot:top>
                <v-btn class="mb-2" color="primary" dark @click="HandelClick">New Connection</v-btn>
                <v-text-field v-model="search" label="Search" class="ml-2"></v-text-field>
            </template>
            <!-- Connection Rows -->
            <template v-slot:item="{ item }">
                <tr>
                    <td>{{ item.Title }}</td>
                    <td>{{ item.Web_Type }}</td>
                    <td>{{ item.url }}</td>
                    <td>{{ item.lastModified }}</td>
                    <td>
                        <v-icon class="mr-2" @click.stop="showDetails(item)">mdi-information-outline</v-icon>
                        <v-icon class="mr-2" @click.stop="editItem(item)">mdi-pencil</v-icon>
                        <v-icon @click.stop="deleteItem(item)">mdi-delete</v-icon>
                    </td>
                </tr>
            </template>
        </v-data-table>

        <div v-if="loading" class="text-center">Loading...</div>
        <div v-else-if="connections.length === 0" class="text-center">There is no data</div>

        <!-- Edit/Create Dialog -->
        <v-dialog v-model="dialog" max-width="500px">
            <v-card>
                <v-card-title>
                    <span class="text-h5">{{ formTitle }}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-col cols="12" md="6">
                                <v-text-field v-model="editedItem.Title" label="Title"></v-text-field>
                            </v-col>
                            <v-col cols="12" md="6">
                                <v-select v-model="editedItem.Web_Type"
                                    :items="['E-commerce Websites', 'Blogs', 'News Websites', 'Educational Websites', 'Entertainment Websites', 'Social Media Websites', 'Portfolio Websites', 'Forums', 'Government Websites', 'Nonprofit Websites', 'Wikis', 'Corporate Websites', 'Healthcare Websites', 'Financial Websites', 'Job Portals', 'Review Sites', 'Personal Websites', 'Dating Websites', 'Directory Sites', 'Streaming Platforms', 'File Sharing Websites', 'Real Estate Websites','Sports','SASS']"
                                    label="Web Type"></v-select>
                            </v-col>
                            <v-col cols="12" md="6">
                                <v-text-field v-model="editedItem.url" label="URL"></v-text-field>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
                    <v-btn color="blue darken-1" text @click="save">Save</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-container>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            dialog: false,
            search: '',
            editedItem: {
                Title: '',
                Web_Type: 'Blogs',
                url: '',
                lastModified: new Date().toISOString().substring(0, 10),
            },
            defaultItem: {
                Title: '',
                Web_Type: 'Blogs',
                url: '',
                lastModified: new Date().toISOString().substring(0, 10),
            },
            connections: [],
            loading: true,
        };
    },
    computed: {
        filteredConnections() {
            return this.connections.filter(connection =>
                connection.Title.toLowerCase().includes(this.search.toLowerCase())
            );
        },
        formTitle() {
            return this.editedItem.Title ? 'Edit Connection' : 'New Connection';
        }
    },
    methods: {
        async fetchConnections() {
            try {
                const response = await axios.get('https://jsonplaceholder.typicode.com/posts'); // Replace with your API endpoint
                this.connections = response.data.map(post => ({
                    Title: post.title,
                    Web_Type: 'Blogs',
                    url: `https://example.com/${post.id}`,
                    lastModified: new Date(post.updatedAt || Date.now()).toISOString().substring(0, 10),
                }));
            } catch (error) {
                console.error('Error fetching connections:', error);
            } finally {
                this.loading = false;
            }
        },
        HandelClick() {
            this.$router.push('/create');
        },
        editItem(item) {
            this.editedItem = { ...item };
            this.dialog = true;
        },
        deleteItem(item) {
            const index = this.connections.indexOf(item);
            if (index > -1) {
                this.connections.splice(index, 1);
            }
        },
        save() {
            const index = this.connections.findIndex(c => c.Title === this.editedItem.Title && c.url === this.editedItem.url);
            if (index === -1) {
                this.connections.push({ ...this.editedItem, lastModified: new Date().toISOString().substring(0, 10) });
            } else {
                this.connections[index] = { ...this.editedItem, lastModified: new Date().toISOString().substring(0, 10) };
            }
            this.dialog = false;
        },
        close() {
            this.dialog = false;
        },
        showDetails(item) {
            alert(`Details for ${item.Title}: Type - ${item.Web_Type}, URL - ${item.url}`);
        }
    },
    mounted() {
        this.fetchConnections();
    }
}
</script>

<style scoped>
.text-center {
    text-align: center;
    margin-top: 20px;
}
</style>
