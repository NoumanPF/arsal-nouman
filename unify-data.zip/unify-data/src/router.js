import Vue from 'vue';
import Router from 'vue-router';
import Dashboard from './components/d/Dashboard.vue';
import Pipelines from './components/d/pipelines.vue';
import Source from './components/d/Source.vue';
import Transformation from './components/d/Transformation.vue';
import Destination from './components/d/Destination.vue';
import BuildAIConnections from './components/d/BuildAIConnections.vue';
import Help from './components/d/Help.vue';
import Workspace from './components/d/Workspace.vue';

Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    { path: '/', component: Home },
    { path: '/dashboard', component: Dashboard },

    { path: '/pipelines', component: Pipelines },
    { path: '/source', component: Source },
    { path: '/transformation', component: Transformation },
    { path: '/destination', component: Destination },
    { path: '/build-ai-connections', component: BuildAIConnections },
    { path: '/help', component: Help },
    { path: '/workspace', component: Workspace },
  ]
});
