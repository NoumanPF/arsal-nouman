<template>
  <v-app theme="light" v-cloak>
    <v-card>
      <v-layout>
        <v-navigation-drawer v-model="drawer" class="bg-white" theme="light" app :rail="rail" v-cloak permanent>
          <div class="header" permanent>
            <v-icon class="bg-white ml-2" style="border-radius: 0%;" icon @click.stop="toggleRail">{{ rail ? 'mdi-menu-open' : 'mdi-menu-close' }}</v-icon>
            <h1 v-if="!rail" class="ma-2 pl-5 mb-1">
              <span class="mr-8" style="color: #023C83;">Unify Data</span>
            </h1>
          </div>
          <v-divider></v-divider>

          <v-list color="transparent" :class="{ 'no-margin-padding': rail }">
           
            <v-list-item v-for="item in items" :key="item.value" @click="handleClick(item.value)"
              :class="{ 'no-margin-padding': rail }">
              <v-icon>{{ item.icon }}</v-icon>
              <span v-if="!rail" class="ml-2">{{ item.title }}</span>
            </v-list-item>
          </v-list>

        

          
        </v-navigation-drawer>

        
        <v-app-bar app class="custom-app-bar">
          <v-toolbar-title class="custom-toolbar-title">Navigation</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-btn icon class="custom-btn">
            <v-icon>mdi-bell</v-icon>
          </v-btn>
        </v-app-bar>


        <v-main style="min-height: 100vh;"></v-main>
      </v-layout>
    </v-card>
  </v-app>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      rail: false,
      drawer: true,
      items: [
        { value: 'Dashboard', icon: 'mdi-view-dashboard', title: 'Dashboard' },
        { value: 'pipe-line', icon: 'mdi-pipe', title: 'Pipelines' },
        { value: 'Source', icon: 'mdi-power-plug', title: 'Source' },
        { value: 'transformation', icon: 'mdi-swap-horizontal-variant', title: 'Transformation' },
        { value: 'destination', icon: 'mdi-map-marker-circle', title: 'Destination' },
        { value: 'build-ai-connection', icon: 'mdi-connection', title: 'Build AI Connections' },
        { value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
        { value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' }
      ],
      editorItems: [
        
      ],
      appendItems: [
        { value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
        { value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' }
      ]
    };
  },
  methods: {
    handleClick(value) {
      console.log(`Item clicked: ${value}`);
    },
    toggleRail() {
      this.rail = !this.rail;
    }
  }
};
</script>

<style scoped>
[v-cloak] {
  display: none;
}

h1 {
  font-family: 'Roboto', sans-serif;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.no-margin-padding {
  margin-left: 05px !important;
  padding: 0 !important;
}

.custom-list-item {
  height: 50px;
  display: flex;
  align-items: center;
}

.custom-list-item:hover {
  background-color: #f5f5f5;
}

.custom-list .v-list-item {
  font-size: 14px;
  color: #494552;
  transition: none; /* Disable transition */
}

.custom-title {
  font-size: 14px;
  font-family: 'Roboto', sans-serif;
  font-weight: bold;
  color: #494552;
}
</style>
