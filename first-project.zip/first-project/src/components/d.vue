<template>

    <v-app>

        <v-container fluid>

            <v-row>

                <v-col cols="12">

                    <v-card>

                        <v-card-title>

                            <v-row class="d-flex align-center">

                                <v-col class="d-flex align-center justify-start">

                                    <v-icon>mdi-calendar</v-icon>

                                    <v-select :items="timeRanges" v-model="selectedTimeRange" dense
                                        class="ml-3"></v-select>

                                </v-col>

                                <v-spacer></v-spacer>

                                <v-btn class="ml-2">This month</v-btn>

                            </v-row>

                        </v-card-title>

                        <v-card-text>

                            <v-row>

                                <v-col v-for="stat in stats" :key="stat.title" cols="12" md="2">

                                    <v-card class="pa-2">

                                        <div class="d-flex flex-column align-center">

                                            <div class="headline">{{ stat.value }}</div>

                                            <div class="subheading">{{ stat.title }}</div>

                                            <div class="caption text-success">{{ stat.percentage }}%</div>

                                        </div>

                                    </v-card>

                                </v-col>

                            </v-row>

                            <v-row>

                                <v-col cols="12" md="8">

                                    <v-card>

                                        <v-card-title>Data Per Connection</v-card-title>

                                        <v-card-text>

                                            <!-- Replace with actual chart component -->

                                            <div class="chart-placeholder">Chart</div>

                                        </v-card-text>

                                    </v-card>

                                </v-col>

                                <v-col cols="12" md="4">

                                    <v-card>

                                        <v-card-title>Connections</v-card-title>

                                        <v-card-text>

                                            <!-- Replace with actual pie chart component -->

                                            <div class="chart-placeholder">Pie Chart</div>

                                        </v-card-text>

                                    </v-card>

                                </v-col>

                            </v-row>

                            <v-row>

                                <v-col cols="12" md="6">

                                    <v-card>

                                        <v-card-title>

                                            Custom Connectors

                                            <v-spacer></v-spacer>

                                            <div>Count <span class="font-weight-bold">{{ connectors.length }}</span>
                                            </div>

                                        </v-card-title>

                                        <v-data-table :headers="connectorHeaders" :items="connectors"
                                            class="elevation-1"></v-data-table>

                                    </v-card>

                                </v-col>

                                <v-col cols="12" md="6">

                                    <v-card>

                                        <v-card-title>

                                            Custom Transformations

                                            <v-spacer></v-spacer>

                                            <div>Count <span class="font-weight-bold">{{ transformations.length
                                                    }}</span></div>

                                        </v-card-title>

                                        <v-data-table :headers="transformationHeaders" :items="transformations"
                                            class="elevation-1"></v-data-table>

                                    </v-card>

                                </v-col>

                            </v-row>

                        </v-card-text>

                    </v-card>

                </v-col>

            </v-row>

        </v-container>

    </v-app>

</template>

<script>

export default {

    data() {

        return {

            timeRanges: ['Last 7 days', 'Last 30 days', 'This month', 'This year'],

            selectedTimeRange: 'This month',

            stats: [

                { title: 'Total Connections', value: 25, percentage: 25 },

                { title: 'Active Connections', value: 14, percentage: 25 },

                { title: 'Disabled Connections', value: 11, percentage: 25 },

                { title: 'Completed Sync', value: 11, percentage: 25 },

                { title: 'Pending Sync', value: 11, percentage: 25 },

            ],

            connectorHeaders: [

                { text: 'Connector Name', value: 'name' },

                { text: 'Type', value: 'type' },

                { text: 'Status', value: 'status' },

                { text: 'Creation Date', value: 'date' },

            ],

            connectors: [

                { name: 'LLM Connector', type: 'Source', status: 'Active', date: '29 July, 2023' },

                { name: 'LLM Connector', type: 'Destination', status: 'Active', date: '29 July, 2023' },

                { name: 'LLM Connector', type: 'Source', status: 'In-active', date: '29 July, 2023' },

                { name: 'LLM Connector', type: 'Destination', status: 'Active', date: '29 July, 2023' },

            ],

            transformationHeaders: [

                { text: 'Connection Name', value: 'name' },

                { text: 'Sync Type', value: 'syncType' },

                { text: 'Status', value: 'status' },

                { text: 'Creation Date', value: 'date' },

            ],

            transformations: [

                { name: 'Connection 1', syncType: 'Real-Time', status: 'Active', date: '29 July, 2023' },

                { name: 'Connection 2', syncType: 'Every 1 hour', status: 'Active', date: '29 July, 2023' },

                { name: 'Connection 3', syncType: 'Every 2 hour', status: 'In-active', date: '29 July, 2023' },

                { name: 'Connection 4', syncType: 'Every 24 hour', status: 'Active', date: '29 July, 2023' },

            ],

        };

    },

};

</script>

<style scoped>
.chart-placeholder {

    width: 100%;

    height: 200px;

    background-color: #f0f0f0;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #666;

}
</style>