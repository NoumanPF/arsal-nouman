<template>
    <v-card>
      <v-layout>
        <v-navigation-drawer class="bg-white" theme="light" >
          <h1 class="ma-2 pl-5 mb-3">
            <v-icon>mdi-menu</v-icon>
            <span class="ml-3" style="color: #023C83;">Airbyte</span>
          </h1>
  
          <v-divider></v-divider>
  
          <v-list-item title="Dashboard"></v-list-item>
  
          <v-list color="transparent" class="ml-5 custom-list">
  
            <v-list-item value="Dashboard">
              <v-icon>mdi-view-dashboard</v-icon>
              <span class="ml-2">Dashboard</span>
            </v-list-item>
  
            <v-list-item value="pipe-line">
              <v-icon>mdi-pipe</v-icon>
              <span class="ml-2">Pipe line</span>
            </v-list-item>
          </v-list>
  
          <v-list-item title="Editor"></v-list-item>
  
          <v-list color="transparent" class="ml-5 custom-list">
            <v-list-item value="Source">
              <v-icon>mdi-power-plug</v-icon>
              <span class="ml-2">Source</span>
              
            </v-list-item>
  
            <v-list-item value="transformation">
              <v-icon>mdi-swap-horizontal-variant</v-icon>
                
                 <span class="ml-2"> Transformation</span>
            </v-list-item>
  
            <v-list-item value="destination">
              <v-icon>mdi-map-marker-circle</v-icon>
              
              <span class="ml-2"> Destination</span>
            </v-list-item>
  
            <v-list-item value="build-ai-connection">
              <v-icon>mdi-connection</v-icon>
             
              <span class="ml-2">  Build AI Connections</span>
            </v-list-item>
  
          </v-list>
  
          <template v-slot:append>
            <div class="pa-2">
  
              <v-list class="custom-list">
                <v-list-item  value="help">
                  <v-icon>mdi-help-circle-outline</v-icon>
                  <span class="ml-2"> Help</span>
                </v-list-item>
                <v-list-item value="workspace">
                  <v-icon>mdi-folder-network-outline</v-icon>
                  <span class="ml-2"> Workspace</span>
                </v-list-item>
                <v-divider></v-divider>
                <v-list-item value="account" >
                  <v-icon>mdi-account-circle-outline</v-icon>
                  <span class="ml-2"> Muhammad Nouman</span>
                </v-list-item>
              </v-list>
  
            </div>
          </template>
        </v-navigation-drawer>
        <v-main style="height:100vh"></v-main>
      </v-layout>
    </v-card>
  </template>
  
  <script>
  
  
  export default {
    name: 'HelloWorld'
  }
  </script>
  
  <style scoped>
  h1 {
    font-family: 'Open Sans', sans-serif;
  }
  
  .custom-list .v-list-item {
    font-size: 14px;
    /* Adjust the font size as needed */
  }
  </style>
  