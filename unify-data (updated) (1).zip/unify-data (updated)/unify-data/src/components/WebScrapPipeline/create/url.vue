<template>
  <v-container>
    <v-form @submit.prevent="submitUrl">
      <v-text-field v-model="url" :rules="rules" label="Enter URL" required></v-text-field>
      <v-btn type="submit" color="primary">Submit</v-btn>
    </v-form>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data: () => ({
    url: '', // Added model for the text field
    rules: [
      value => !!value || 'Required.',
      value => (value || '').length <= 10000 || 'Max 10000 characters',
      value => {
        const pattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([\/\w \.-]*)*\/?$/;
        return pattern.test(value) || 'Invalid URL.';
      },
    ],
  }),
  methods: {
    submitUrl() {
      const apiUrl = 'http://10.0.52.179:8081/api/website-info';  
      const postData = {
        url: this.url
      };
      axios.post(apiUrl, postData, {
        headers: {

          'Authorization': `Bearer 66b333ab02f04cf3ff04be0c|QbMjwjQaDKTuMqXiI1OUAl1rGWo9ABwcSyeNWN0o0362a37b` // Include token in request headers

        }
      }).then(response => {
        console.log('Response:', response.data);
        alert('URL submitted successfully!');
      })
        .catch(error => {
          console.error('Error posting URL:', error);
          alert('Failed to submit URL');
        });
    }
  }
}
</script>
