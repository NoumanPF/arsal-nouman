<template>
    <v-container fluid>
      <v-row>
        <ul style="list-style: none; padding: 0;">
          <li v-for="(link, index) in links" :key="index" class="d-flex align-items-center">
            <input type="checkbox" v-model="link.checked" class="mr-2">
            <a :href="link.href" target="_blank" rel="noopener noreferrer" style="text-decoration: none; color: inherit;">
              {{ link.href }}
            </a>
          </li>
        </ul>
        <v-btn @click="handleSubmit" color="primary">Submit</v-btn>
      </v-row>
    </v-container>
  </template>
  
  <script>
  export default {
    props: {
      links: {
        type: Array,
        required: true
      },
      url: {
        type: String,
        required: true
      }
    },
    methods: {
      handleSubmit() {
        const selectedLinks = this.links.filter(link => link.checked);
        this.$emit('update-links', selectedLinks);
      }
    }
  }
  </script>
  
  <style scoped>
  .d-flex {
    display: flex;
  }
  .align-items-center {
    align-items: center;
  }
  .mr-2 {
    margin-right: 8px;
  }
  </style>
  