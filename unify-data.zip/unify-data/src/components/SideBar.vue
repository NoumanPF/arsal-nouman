<template> 

           <NavigationDrower/>
</template>

<script>
import NavigationDrower from './NavigationDrower.vue';
</script>