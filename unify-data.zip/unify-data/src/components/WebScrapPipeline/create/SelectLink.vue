<template>
    <v-container fluid>
        <v-row>
            <ul  style="list-style: none; padding: 0;">
                <li v-for="(link, index) in links" :key="index" class="d-flex align-items-center">
                    <input type="checkbox" v-model="link.checked" class="mr-2">
                    <a  target="_blank" rel="noopener noreferrer"
                        style="text-decoration: none; color: inherit;">
                        {{ link.text }}
                    </a>
                </li>
            </ul>

        </v-row>
    </v-container>
</template>

<script>
export default {
    data() {
        return {
            links: [
                { value: "Google", text: "https://www.google.com", checked: false },
                { value: "Facebook", text: "https://www.facebook.com", checked: false },
                { value: "Twitter", text: "https://www.twitter.com", checked: false },
                { value: "LinkedIn", text: "https://www.linkedin.com", checked: false },
                { value: "GitHub", text: "https://www.github.com", checked: false }
            ]
        }
    },
}
</script>