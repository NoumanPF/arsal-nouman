<template>

    <v-container>

        <!-- Data Table with static headers and search -->

        <v-data-table :items="filteredConnections" :headers="headers" class="border">

            <template v-slot:top>

                <v-btn class="mb-2" color="primary" dark @click="HandelClick">New Connection</v-btn>

                <v-text-field v-model="search" label="Search" class="ml-2"></v-text-field>

            </template>

            <template v-slot:item="{ item }">

                <tr>

                    <td>{{ item.Title }}</td>

                    <td>{{ item.Web_Type }}</td>

                    <td>{{ item.url }}</td>

                    <td>{{ item.lastModified }}</td>

                    <td>

                        <v-icon class="mr-2" @click.stop="showDetails(item)">mdi-information-outline</v-icon>

                        <v-icon class="mr-2" @click.stop="editItem(item)">mdi-pencil</v-icon>

                        <v-icon @click.stop="confirmDelete(item)">mdi-delete</v-icon>

                    </td>

                </tr>

            </template>

        </v-data-table>



        <div v-if="loading" class="text-center">Loading...</div>

        <div v-else-if="connections.length === 0" class="text-center">There is no data</div>



        <!-- Edit/Create Dialog -->

        <v-dialog v-model="dialog" max-width="500px">

            <v-card>

                <v-card-title>

                    <span class="text-h5">{{ formTitle }}</span>

                </v-card-title>

                <v-card-text>

                    <v-container>

                        <v-row>

                            <v-col cols="12">

                                <v-text-field v-model="editedItem.Title" label="Title"></v-text-field>

                            </v-col>

                        </v-row>

                    </v-container>

                </v-card-text>

                <v-card-actions>

                    <v-spacer></v-spacer>

                    <v-btn color="blue darken-1" text @click="closeDialog">Cancel</v-btn>

                    <v-btn color="blue darken-1" text @click="save">Save</v-btn>

                </v-card-actions>

            </v-card>

        </v-dialog>



        <!-- Confirmation Dialog -->

        <v-dialog v-model="confirmationDialog" max-width="400px">

            <v-card>

                <v-card-title class="headline">Confirm Delete</v-card-title>

                <v-card-text>Do you want to delete this from the table?</v-card-text>

                <v-card-actions>

                    <v-spacer></v-spacer>

                    <v-btn color="red darken-1" text @click="deleteConnection">Yes</v-btn>

                    <v-btn color="blue darken-1" text @click="closeConfirmationDialog">No</v-btn>

                </v-card-actions>

            </v-card>

        </v-dialog>

    </v-container>

</template>



<script>

import axios from 'axios';



export default {

    data() {

        return {

            dialog: false,

            confirmationDialog: false,

            itemToDelete: null,

            search: '',

            editedItem: {

                Title: '',

                Web_Type: 'Blogs',

                url: '',

                lastModified: new Date().toISOString().substring(0, 10),

            },

            defaultItem: {

                Title: '',

                Web_Type: 'Blogs',

                url: '',

                lastModified: new Date().toISOString().substring(0, 10),

            },

            connections: [],

            loading: true,

            // Static headers for the table

            headers: [

                { text: 'Name', value: 'Title' },

                { text: 'Destination Name', value: 'Web_Type' },

                { text: 'Source URL', value: 'url' },

                { text: 'Last Modified', value: 'lastModified' },

                { text: 'Actions', value: 'actions', sortable: false }

            ],

        };

    },

    computed: {

        filteredConnections() {

            return this.connections.filter(connection =>

                connection.Title.toLowerCase().includes(this.search.toLowerCase())

            );

        },

        formTitle() {

            return this.editedItem.Title ? 'Edit Connection' : 'New Connection';

        }

    },

    methods: {

        async fetchConnections() {

            this.loading = true;

            try {

                const response = await axios.get('http://10.0.52.168:8081/api/web-extraction-pipelines', {

                    headers: {

                        'Authorization': `Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b`

                    }

                });



                console.log('API Response:', response.data);



                if (Array.isArray(response.data.data)) {

                    this.connections = response.data.data.map(item => ({

                        id: item.id,

                        Title: item.name || '',

                        Web_Type: item.destination_name || 'Unknown',

                        url: item.resource_paths[0] || '',

                        lastModified: item.sync_time ? new Date(item.sync_time).toISOString().substring(0, 10) : new Date().toISOString().substring(0, 10),

                    }));

                } else {

                    console.error('Expected an array but got:', response.data);

                }

            } catch (error) {

                console.error('Error fetching connections:', error);

            } finally {

                this.loading = false;

            }

        },

        async save() {

            try {

                if (this.editedItem.id) {

                    const payload = {

                        Title: this.editedItem.Title,

                    };

                    console.log('Updating with payload:', payload);

                    await axios.put(`http://10.0.52.168:8081/api/web-extraction-pipelines/${this.editedItem.id}`, payload, {

                        headers: {

                            'Authorization': `Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b`

                        }

                    });

                    const index = this.connections.findIndex(c => c.id === this.editedItem.id);

                    if (index !== -1) {

                        this.connections[index] = { ...this.editedItem, lastModified: new Date().toISOString().substring(0, 10) };

                    }

                } else {

                    const payload = {

                        Title: this.editedItem.Title,

                        Web_Type: this.editedItem.Web_Type,

                        url: this.editedItem.url,

                        lastModified: new Date().toISOString().substring(0, 10),

                    };

                    const response = await axios.post('http://10.0.52.168:8081/api/web-extraction-pipelines', payload, {

                        headers: {

                            'Authorization': `Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b`

                        }

                    });

                    this.connections.push({ ...this.editedItem, id: response.data.id, lastModified: new Date().toISOString().substring(0, 10) });

                }

            } catch (error) {

                console.error('Error saving connection:', error);

            }

            this.dialog = false;

        },

        confirmDelete(item) {

            this.itemToDelete = item;

            this.confirmationDialog = true;

        },

        async deleteConnection() {

            if (this.itemToDelete && this.itemToDelete.id) {

                try {

                    console.log('Deleting ID:', this.itemToDelete.id);

                    await axios.delete(`http://10.0.52.168:8081/api/web-extraction-pipelines/${this.itemToDelete.id}`, {

                        headers: {

                            'Authorization': `Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b`

                        }

                    });

                    const index = this.connections.findIndex(c => c.id === this.itemToDelete.id);

                    if (index > -1) {

                        this.connections.splice(index, 1);

                    }

                } catch (error) {

                    console.error('Error deleting connection:', error);

                }

                this.itemToDelete = null;

            } else {

                console.error('Item to delete does not have a valid ID:', this.itemToDelete);

            }

            this.confirmationDialog = false;

        },

        closeConfirmationDialog() {

            this.confirmationDialog = false;

            this.itemToDelete = null;

        },

        HandelClick() {

            this.$router.push('/create');

        },

        editItem(item) {

            this.editedItem = { ...item };

            this.dialog = true;

        },

        closeDialog() {

            this.dialog = false;

        },

        showDetails(item) {

            alert(`Details for ${item.Title}: Type - ${item.Web_Type}, URL - ${item.url}`);

        }

    },

    mounted() {

        this.fetchConnections();

    }

}

</script>



<style scoped>
.text-center {

    text-align: center;

    margin-top: 20px;

}
</style>