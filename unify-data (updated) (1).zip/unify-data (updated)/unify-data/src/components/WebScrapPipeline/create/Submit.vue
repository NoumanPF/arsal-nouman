<template>
    <v-container>
        <v-form>
            <!-- Button to Fetch Destinations -->
            <v-btn color="primary" @click="fetchDestinations" class="mb-3">Fetch Destinations</v-btn>

            <!-- Dropdown for Selecting a Destination -->
            <v-select v-model="selectedDestination" :items="destinations" label="Select a Destination" outlined class="mb-3"></v-select>

            <!-- Sync Time Input -->
            <v-text-field v-model.number="syncValue" label="Sync Time Value" outlined type="number" class="mb-3"></v-text-field>

            <!-- Dropdown for Sync Time Units -->
            <v-select v-model="syncUnit" :items="units" label="Select Time Unit" outlined class="mb-3"></v-select>

            <!-- Submit Button -->
            <v-btn color="primary" @click="submitData" class="mb-3">Submit</v-btn>
        </v-form>
    </v-container>
</template>

<script>
import axios from 'axios';

export default {
    props: {
        selectedLinks: {
            type: Array,
            required: true
        }
    },
    data() {
        return {
            selectedDestination: null,
            syncValue: 0, // Ensure the default value is a number
            syncUnit: null,
            units: ['Days', 'Hours', 'Minutes'],
            destinations: []  // This will hold names of destinations
        };
    },
    methods: {
        fetchDestinations() {
            const apiUrl = 'http://10.0.52.179:8081/api/connectors';
            axios.get(apiUrl, {
                headers: {
                    'Authorization': 'Bearer 66b333ab02f04cf3ff04be0c|QbMjwjQaDKTuMqXiI1OUAl1rGWo9ABwcSyeNWN0o0362a37b'
                }
            }).then(response => {
                this.destinations = response.data.destinations.map(item => item.name);  // Assuming response.data is an array of objects
                console.log("Fetched destinations:", this.destinations);
            })
            .catch(error => {
                console.error("Error fetching destinations:", error);
                alert('Failed to fetch destinations');
            });
        },
        submitData() {
            const payload = {
                selectedLinks: this.selectedLinks,
                selectedDestination: this.selectedDestination,
                syncTime: this.convertedSyncTime
            };

            const apiUrl = 'http://your-api-endpoint.com/api/submit'; // Replace with your API endpoint
            axios.post(apiUrl, payload, {
                headers: {
                    'Authorization': 'Bearer your-auth-token' // Replace with your auth token
                }
            }).then(response => {
                console.log('Submission successful:', response.data);
                alert('Data submitted successfully');
            })
            .catch(error => {
                console.error('Error submitting data:', error);
                alert('Failed to submit data');
            });
        }
    },
    computed: {
        convertedSyncTime() {
            const value = parseFloat(this.syncValue);
            if (isNaN(value) || value <= 0 || !this.syncUnit) {
                return 0;
            }
            let seconds = 0;
            switch (this.syncUnit) {
                case 'Days':
                    seconds = value * 86400; // 1 day = 86400 seconds
                    break;
                case 'Hours':
                    seconds = value * 3600; // 1 hour = 3600 seconds
                    break;
                case 'Minutes':
                    seconds = value * 60; // 1 minute = 60 seconds
                    break;
            }
            return seconds;
        }
    }
};
</script>

<style scoped>
/* Additional styles can be added here if needed */
</style>
