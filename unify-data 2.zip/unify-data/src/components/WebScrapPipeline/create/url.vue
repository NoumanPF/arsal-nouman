<template>
  <v-container>
    <v-form @submit.prevent="submitUrl">
      <v-text-field v-model="url" :rules="rules" label="Enter URL" required></v-text-field>
      <v-btn type="submit" color="primary">Submit</v-btn>
    </v-form>
    
   
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data: () => ({
    url: '',
    hrefs: [], // Store the URLs here
    rules: [
      value => !!value || 'Required.',
      value => (value || '').length <= 10000 || 'Max 10000 characters',
      value => {
        const pattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([\/\w \.-]*)*\/?$/;
        return pattern.test(value) || 'Invalid URL.';
      },
    ],
  }),

  methods: {
    submitUrl() {
      const apiUrl = 'http://10.0.52.168:8081/api/website-info';
      const postData = { url: this.url };

      axios.post(apiUrl, postData, {
        headers: {
          'Authorization': 'Bearer 66b4bd9ba6aa52a5490dd89e|UdDM3fYiNoXBD1FfNxCHSxcoDmB03YIB8dD1H9lH5d688b5b'
        }
      }).then(response => {
        this.processHrefs(response.data.data);
        alert('URL submitted successfully!');
      }).catch(error => {
        console.error('Error posting URL:', error);
        alert('Failed to submit URL');
      });
    },
    processHrefs(data) {
      if (data && Array.isArray(data) && data.length > 0) {
        // Extract URLs from the object
        this.hrefs = Object.values(data[0]);
        this.$emit('links-received', this.hrefs);
        console.log('Extracted Hrefs:', this.hrefs);
      } else {
        this.hrefs = [];
        console.log('No data received or data format incorrect:', data);
      }
    }
  }
}
</script>
