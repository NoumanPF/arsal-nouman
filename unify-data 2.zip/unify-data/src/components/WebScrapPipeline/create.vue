<template>
    <v-stepper v-model="step" :items="items" show-actions>
      <template v-slot:item.1>
        <h3 class="text-h6">Enter URL you want to scrap:</h3>
        <br>
        <!-- Component to enter URL and receive links -->
        <Url @links-received="handleLinksReceived" @url-updated="handleUrlUpdated"></Url>
      </template>
  
      <template v-slot:item.2>
        <h3 class="text-h6">Select multiple links you want to scrap:</h3>
        <!-- Component to select links from received list -->
        <SelectLink :links="linksToScrape" :url="url" @update-links="handleUpdateLinks"></SelectLink>
      </template>
  
      <template v-slot:item.3>
        <!-- Pass URL and selected links to the Submit component -->
        <Submit :url="url" :selected-links="selectedLinks"></Submit>
      </template>
    </v-stepper>
  </template>
  
  <script>
  import Url from './create/url.vue';
  import SelectLink from './create/SelectLink.vue';
  import Submit from './create/Submit.vue';
  
  export default {
    components: { Url, SelectLink, Submit },
    data: () => ({
      step: 1,
      items: ['Enter URL', 'Select Links', 'Submit'],
      linksToScrape: [],
      url: '',
      selectedLinks: [] // Add a data property to store selected links
    }),
    methods: {
      handleLinksReceived(links) {
        if (!links) {
          console.error('No links received');
          return;
        }
        // Add checked property to each link for checkbox tracking
        this.linksToScrape = links.map(link => ({ href: link, checked: false }));
        console.log('Received links:', this.linksToScrape);
      },
      handleUrlUpdated(url) {
        this.url = url;
        console.log('URL updated:', this.url);
      },
      handleUpdateLinks(selectedLinks) {
        this.selectedLinks = selectedLinks;
        console.log('Selected links:', this.selectedLinks);
      }
    }
  }
  </script>
  